import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class ConfirmPickUpPage extends StatefulWidget {
  @override
  _ConfirmPickUpPageState createState() => _ConfirmPickUpPageState();
}

class _ConfirmPickUpPageState extends State<ConfirmPickUpPage> {
  String destination = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            flex: 5,
            child: Container(
              child: GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: LatLng(-1.286389, 36.817223), // Example coordinates for Nairobi
                  zoom: 14,
                ),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              color: Color(0xFFE5E5E5),
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 10,
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Westlands Square',
                                style: TextStyle(
                                  fontSize: 28,
                                  
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Economy',
                                style: TextStyle(
                                  color: Color(0xFF838383),
                              
                                ),
                              ),
                              Text(
                                'Ksh 500',
                                style: TextStyle(
                                  color: Color(0xFF838383),
                              
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          CustomPressableButton(title: "Confirm Pickup point", showIcon: false),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CustomPressableButton extends StatelessWidget {
  final String title;
  final bool showIcon;

  CustomPressableButton({required this.title, this.showIcon = true});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        // Handle button press
      },
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (showIcon)
            Icon(
              Icons.check,
              color: Colors.white,
            ),
          Text(title),
        ],
      ),
    );
  }
}
