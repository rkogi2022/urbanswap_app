import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class ChooseRidePage extends StatefulWidget {
  @override
  _ChooseRidePageState createState() => _ChooseRidePageState();
}

class _ChooseRidePageState extends State<ChooseRidePage> {
  String destination = "";
  String selectedPayment = "Cash";
  bool showDropdown = false;

  void chooseRide(String selectedDestination) {
    setState(() {
      destination = selectedDestination;
    });
  }

  void toggleDropdown() {
    setState(() {
      showDropdown = !showDropdown;
    });
  }

  void selectPayment(String paymentOption) {
    setState(() {
      selectedPayment = paymentOption;
      showDropdown = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              child: GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: LatLng(0.0, 0.0),
                  zoom: 10,
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: Colors.grey[200],
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      'Choose a ride',
                      style: TextStyle(fontSize: 20),
                    ),
                  ),
                  buildRideOption('Basic', '3 minutes away', 'assets/images/basic_car.png', 450),
                  buildRideOption('Economy', '3 minutes away', 'assets/images/economy_car.png', 500),
                  buildRideOption('Urban Boda', '3 minutes away', 'assets/images/boda.png', 250),
                  buildRideOption('E-Comfort', '3 minutes away', 'assets/images/basic_car.png', 350),
                  buildPaymentCard(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildRideOption(String type, String time, String imagePath, int price) {
    return Column(
      children: <Widget>[
        ListTile(
          leading: Image.asset(imagePath, width: 70),
          title: Text(type),
          subtitle: Text(time),
          trailing: Text('KSH $price'),
          onTap: () => chooseRide(type),
        ),
        Divider(),
      ],
    );
  }

  Widget buildPaymentCard() {
    return Card(
      margin: EdgeInsets.all(16.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      elevation: 10,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(Icons.payment, color: Colors.green),
                SizedBox(width: 8),
                GestureDetector(
                  onTap: toggleDropdown,
                  child: Text(
                    selectedPayment,
                    style: TextStyle(fontSize: 16),
                  ),
                ),
                Icon(showDropdown ? Icons.arrow_drop_up : Icons.arrow_drop_down),
              ],
            ),
            if (showDropdown)
              Column(
                children: <Widget>[
                  ListTile(
                    title: Text('Cash'),
                    onTap: () => selectPayment('Cash'),
                  ),
                  ListTile(
                    title: Text('Wallet'),
                    onTap: () => selectPayment('Wallet'),
                  ),
                ],
              ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {},
              child: Text('Choose $destination'),
            ),
          ],
        ),
      ),
    );
  }
}
