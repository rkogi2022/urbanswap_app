import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class TripDetailsPage extends StatelessWidget {
  BuildContext? get context => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            flex: 16,
            child: Container(
              child: GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: LatLng(-1.286389, 36.817223),
                  zoom: 14,
                ),
              ),
            ),
          ),
          Expanded(
            flex: 14,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 10),
                  Text(
                    'Trip Details',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 10),
                  buildDetailSection('Westlands Square', 'Kenyatta International Convention', context),
                  buildAmountSection('Ksh450', 'Cash', context),
                  SizedBox(height: 10),
                  buildButton('Cancel trip', () {
                    // Cancel trip logic
                  }),
                  buildMainButton('Done', () {
                    // Done logic
                  }),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildDetailSection(String start, String end, BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.symmetric(vertical: 10),
          child: Text(
            start,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              end,
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            ElevatedButton(
              onPressed: () {
                print("Edit pressed");
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFFE3E3E3),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text('Edit'),
            ),
          ],
        ),
      ],
    );
  }

  Widget buildAmountSection(String amount, String method, BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Icon(Icons.person, size: 17, color: Color(0xFF003D8E)),
            SizedBox(width: 5),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  amount,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(
                  method,
                  style: TextStyle(color: Color(0xFF838383), fontSize: 12),
                ),
              ],
            ),
          ],
        ),
        ElevatedButton(
          onPressed: () {
            print("Switch pressed");
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFFE3E3E3),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          child: Text('Switch'),
        ),
      ],
    );
  }

  Widget buildButton(String text, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: Color(0xFFE1E1E1),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        elevation: 3,
      ),
      child: Text(text),
    );
  }

  Widget buildMainButton(String text, VoidCallback onPressed) {
    return Padding(
      padding: EdgeInsets.only(top: 10),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Theme.of(context!).primaryColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          elevation: 3,
        ),
        child: Text(text),
      ),
    );
  }
}
